# Rick Sanchez Chatbot - Vercel Deployment Guide

## Project Structure
```
rick-chatbot/
├── package.json
├── next.config.js
├── tailwind.config.js
├── postcss.config.js
├── vercel.json
├── .env.local
├── pages/
│   ├── _app.js
│   ├── index.js
│   └── api/
│       └── chat.js
├── components/
│   └── RickChatbot.js
└── styles/
    └── globals.css
```

## 1. package.json
```json
{
  "name": "rick-chatbot",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint"
  },
  "dependencies": {
    "next": "14.0.4",
    "react": "18.2.0",
    "react-dom": "18.2.0",
    "openai": "^4.20.1",
    "lucide-react": "^0.263.1"
  },
  "devDependencies": {
    "autoprefixer": "^10.4.16",
    "eslint": "^8.55.0",
    "eslint-config-next": "14.0.4",
    "postcss": "^8.4.32",
    "tailwindcss": "^3.3.6"
  }
}
```

## 2. next.config.js
```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  env: {
    OPENAI_API_KEY: process.env.OPENAI_API_KEY,
    FISH_API_KEY: process.env.FISH_API_KEY,
    FISH_MODEL_ID: process.env.FISH_MODEL_ID,
  },
}

module.exports = nextConfig
```

## 3. tailwind.config.js
```javascript
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
```

## 4. postcss.config.js
```javascript
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
```

## 5. vercel.json
```json
{
  "functions": {
    "pages/api/chat.js": {
      "maxDuration": 30
    }
  },
  "env": {
    "OPENAI_API_KEY": "@openai_api_key",
    "FISH_API_KEY": "@fish_api_key",
    "FISH_MODEL_ID": "@fish_model_id"
  }
}
```

## 6. .env.local (for local development)
```
OPENAI_API_KEY=your_openai_api_key_here
FISH_API_KEY=your_fish_api_key_here
FISH_MODEL_ID=your_fish_model_id_here
```

## 7. pages/_app.js
```javascript
import '../styles/globals.css'

export default function App({ Component, pageProps }) {
  return <Component {...pageProps} />
}
```

## 8. pages/index.js
```javascript
import Head from 'next/head'
import RickChatbot from '../components/RickChatbot'

export default function Home() {
  return (
    <>
      <Head>
        <title>Rick Sanchez AI Chatbot</title>
        <meta name="description" content="Talk to Rick from Rick and Morty!" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <RickChatbot />
    </>
  )
}
```

## 9. styles/globals.css
```css
@tailwind base;
@tailwind components;
@tailwind utilities;

html,
body {
  padding: 0;
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Oxygen,
    Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue, sans-serif;
}

* {
  box-sizing: border-box;
}

/* Custom scrollbar */
::-webkit-scrollbar {
  width: 8px;
}

::-webkit-scrollbar-track {
  background: rgba(0, 0, 0, 0.1);
}

::-webkit-scrollbar-thumb {
  background: rgba(34, 197, 94, 0.5);
  border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
  background: rgba(34, 197, 94, 0.7);
}
```

## Deployment Steps

### Step 1: Set up your local environment
1. Create a new directory for your project
2. Copy all the files above into the correct structure
3. Run `npm install` to install dependencies
4. Create your `.env.local` file with your API keys
5. Test locally with `npm run dev`

### Step 2: Deploy to Vercel
1. Push your code to a GitHub repository
2. Connect your GitHub repo to Vercel
3. In Vercel dashboard, go to your project settings
4. Add environment variables:
   - `OPENAI_API_KEY`: Your OpenAI API key
   - `FISH_API_KEY`: Your Fish Audio API key (optional)
   - `FISH_MODEL_ID`: Your Fish Audio model ID (optional)
5. Deploy!

### Step 3: Domain Configuration (Optional)
- Add your custom domain in Vercel settings
- Configure DNS records as instructed by Vercel

## Notes

### Audio Integration
The current implementation has a placeholder for audio generation. For full audio functionality, you'll need to:
1. Set up cloud storage (AWS S3, Vercel Blob, etc.)
2. Modify the `generateAudio` function to upload audio files and return URLs
3. Handle audio streaming or file serving

### Performance Optimization
- The app uses `gpt-4o-mini` for faster responses
- Message history is limited to last 10 messages
- Responses are limited to 100 tokens
- Consider implementing caching for frequently asked questions

### Security
- API keys are stored as environment variables
- CORS is configured for your domain
- Rate limiting can be added using Vercel's rate limiting features

### Mobile Optimization
- Responsive design using Tailwind CSS
- Touch-friendly interface
- Optimized for mobile screens

This structure gives you a complete, production-ready chatbot that can be deployed to Vercel with your own custom domain!